import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./TherapistDashboard.css";
import api from "../services/api";

export default function TherapistDashboard() {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchPatients() {
      try {
        const res = await api.get("/therapist/patients");
        setPatients(res.data.patients || []);
      } catch (err) {
        setError(err.response?.data?.detail || "Failed to load patient list");
      } finally {
        setLoading(false);
      }
    }
    fetchPatients();
  }, []);

  const handlePatientClick = (patientId) => {
    navigate(`/therapist/patient/${patientId}`);
  };

  return (
    <main className="td-page">
      <div className="td-inner">
        {/* Header */}
        <div className="td-header">
          <div>
            <h1 className="td-title">My Patients</h1>
            <p className="td-subtitle">
              View journal entries and mood trends for patients who have enabled sharing
            </p>
          </div>
        </div>

        {/* Patient list */}
        {loading ? (
          <div className="td-empty">Loading patients...</div>
        ) : error ? (
          <div className="td-error">{error}</div>
        ) : patients.length === 0 ? (
          <div className="td-empty">
            <div className="td-empty__icon">👥</div>
            <div className="td-empty__text">No patients linked yet</div>
            <div className="td-empty__hint">
              Patients can link to your account using your therapist ID in their Settings
            </div>
          </div>
        ) : (
          <div className="td-grid">
            {patients.map((patient) => (
              <button
                key={patient.patient_id}
                className="td-card"
                onClick={() => handlePatientClick(patient.patient_id)}
              >
                {/* Avatar */}
                <div className="td-card__avatar">
                  {patient.name.charAt(0).toUpperCase()}
                </div>

                {/* Info */}
                <div className="td-card__info">
                  <div className="td-card__name">{patient.name}</div>
                  <div className="td-card__email">{patient.email}</div>
                </div>

                {/* Sharing status */}
                <div className="td-card__footer">
                  {patient.sharing_enabled ? (
                    <span className="td-badge td-badge--on">Sharing enabled</span>
                  ) : (
                    <span className="td-badge td-badge--off">Sharing paused</span>
                  )}
                </div>

                {/* Arrow icon */}
                <div className="td-card__arrow" aria-hidden="true">
                  →
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}