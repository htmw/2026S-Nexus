import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./PatientView.css";
import api from "../services/api";

export default function PatientView() {
  const { patientId } = useParams();
  const navigate = useNavigate();

  const [profile, setProfile] = useState(null);
  const [entries, setEntries] = useState([]);
  const [moodTrend, setMoodTrend] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("journal"); // "journal" | "mood"

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      setError(null);
      try {
        const [profileRes, journalRes, moodRes] = await Promise.all([
          api.get(`/therapist/patients/${patientId}/profile`),
          api.get(`/therapist/patients/${patientId}/journal`),
          api.get(`/therapist/patients/${patientId}/mood`),
        ]);
        setProfile(profileRes.data);
        setEntries(journalRes.data.entries || []);
        setMoodTrend(moodRes.data.points || []);
      } catch (err) {
        const status = err.response?.status;
        const detail = err.response?.data?.detail;
        if (status === 403) {
          setError(detail || "This patient has not shared their data with you.");
        } else {
          setError(detail || "Failed to load patient data");
        }
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [patientId]);

  const formatDate = (isoString) => {
    try {
      return new Date(isoString).toLocaleDateString(undefined, {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    } catch {
      return isoString;
    }
  };

  const getSentimentColor = (label) => {
    if (label === "positive") return "#62a88e";
    if (label === "negative") return "#c0392b";
    return "#6f7a80";
  };

  const getSentimentEmoji = (label) => {
    if (label === "positive") return "😊";
    if (label === "negative") return "😔";
    return "😐";
  };

  return (
    <main className="pv-page">
      <div className="pv-inner">
        {/* Back button + header */}
        <button className="pv-back" onClick={() => navigate("/therapist/dashboard")}>
          ← Back to patients
        </button>

        {loading ? (
          <div className="pv-loading">Loading patient data...</div>
        ) : error ? (
          <div className="pv-error-card">
            <div className="pv-error-icon">🔒</div>
            <div className="pv-error-title">Access Restricted</div>
            <div className="pv-error-text">{error}</div>
            <button className="pv-error-btn" onClick={() => navigate("/therapist/dashboard")}>
              Return to dashboard
            </button>
          </div>
        ) : (
          <>
            {/* Patient header */}
            <div className="pv-header">
              <div className="pv-header__avatar">
                {profile?.name.charAt(0).toUpperCase()}
              </div>
              <div className="pv-header__info">
                <h1 className="pv-header__name">{profile?.name}</h1>
                <p className="pv-header__email">{profile?.email}</p>
              </div>
              {profile?.sharing_enabled && (
                <div className="pv-header__badge">Sharing enabled</div>
              )}
            </div>

            {/* Tab navigation */}
            <div className="pv-tabs">
              <button
                className={`pv-tab ${activeTab === "journal" ? "is-active" : ""}`}
                onClick={() => setActiveTab("journal")}
              >
                Journal Entries
                <span className="pv-tab__count">{entries.length}</span>
              </button>
              <button
                className={`pv-tab ${activeTab === "mood" ? "is-active" : ""}`}
                onClick={() => setActiveTab("mood")}
              >
                Mood Trend
                <span className="pv-tab__count">{moodTrend.length}</span>
              </button>
            </div>

            {/* Tab content */}
            {activeTab === "journal" ? (
              <div className="pv-content">
                {entries.length === 0 ? (
                  <div className="pv-empty">
                    <div className="pv-empty__icon">📓</div>
                    <div className="pv-empty__text">No shared entries yet</div>
                    <div className="pv-empty__hint">
                      This patient hasn't shared any journal entries with you
                    </div>
                  </div>
                ) : (
                  <div className="pv-entries">
                    {entries.map((entry, idx) => (
                      <article key={idx} className="pv-entry">
                        <div className="pv-entry__header">
                          <span className="pv-entry__date">{formatDate(entry.date)}</span>
                          <span
                            className="pv-entry__sentiment"
                            style={{ color: getSentimentColor(entry.sentiment_label) }}
                          >
                            {getSentimentEmoji(entry.sentiment_label)}{" "}
                            {entry.sentiment_label || "neutral"}
                          </span>
                        </div>
                        <div className="pv-entry__text">{entry.text}</div>
                      </article>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="pv-content">
                {moodTrend.length === 0 ? (
                  <div className="pv-empty">
                    <div className="pv-empty__icon">📈</div>
                    <div className="pv-empty__text">No mood data yet</div>
                    <div className="pv-empty__hint">
                      Mood trend will appear once the patient shares entries with sentiment analysis
                    </div>
                  </div>
                ) : (
                  <div className="pv-trend">
                    <div className="pv-trend__header">
                      <h2 className="pv-trend__title">Sentiment Over Time</h2>
                      <p className="pv-trend__subtitle">
                        {moodTrend.length} data points from shared entries
                      </p>
                    </div>
                    <div className="pv-trend__list">
                      {moodTrend.map((point, idx) => (
                        <div key={idx} className="pv-trend-point">
                          <div className="pv-trend-point__date">
                            {formatDate(point.date)}
                          </div>
                          <div className="pv-trend-point__bar-wrapper">
                            <div
                              className="pv-trend-point__bar"
                              style={{
                                width: `${Math.min(point.confidence_score * 100, 100)}%`,
                                background: getSentimentColor(point.sentiment_label),
                              }}
                            />
                          </div>
                          <div
                            className="pv-trend-point__label"
                            style={{ color: getSentimentColor(point.sentiment_label) }}
                          >
                            {getSentimentEmoji(point.sentiment_label)}{" "}
                            {point.sentiment_label}
                          </div>
                          <div className="pv-trend-point__confidence">
                            {Math.round(point.confidence_score * 100)}%
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </main>
  );
}